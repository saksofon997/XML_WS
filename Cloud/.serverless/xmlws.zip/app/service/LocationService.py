def locate(event, context):
    pass
